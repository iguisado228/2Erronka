package Bezeroak;

public class bezeroa {
	
	private int idBezeroa;
	private String nan, izena, abizena, telefonoa, helbidea, erabiltzaileIzena, pasahitza, helbideElektronikoa;
	
	
	public bezeroa(int idBezeroa, String nan, String izena, String abizena, String telefonoa, String helbidea,
			String erabiltzaileIzena, String pasahitza, String helbideElektronikoa) {
		this.idBezeroa = idBezeroa;
		this.nan = nan;
		this.izena = izena;
		this.abizena = abizena;
		this.telefonoa = telefonoa;
		this.helbidea = helbidea;
		this.erabiltzaileIzena = erabiltzaileIzena;
		this.pasahitza = pasahitza;
		this.helbideElektronikoa = helbideElektronikoa;
	}


	/**
	 * @return the idBezeroa
	 */
	public int getIdBezeroa() {
		return idBezeroa;
	}


	/**
	 * @param idBezeroa the idBezeroa to set
	 */
	public void setIdBezeroa(int idBezeroa) {
		this.idBezeroa = idBezeroa;
	}


	/**
	 * @return the nan
	 */
	public String getNan() {
		return nan;
	}


	/**
	 * @param nan the nan to set
	 */
	public void setNan(String nan) {
		this.nan = nan;
	}


	/**
	 * @return the izena
	 */
	public String getIzena() {
		return izena;
	}


	/**
	 * @param izena the izena to set
	 */
	public void setIzena(String izena) {
		this.izena = izena;
	}


	/**
	 * @return the abizena
	 */
	public String getAbizena() {
		return abizena;
	}


	/**
	 * @param abizena the abizena to set
	 */
	public void setAbizena(String abizena) {
		this.abizena = abizena;
	}


	/**
	 * @return the telefonoa
	 */
	public String getTelefonoa() {
		return telefonoa;
	}


	/**
	 * @param telefonoa the telefonoa to set
	 */
	public void setTelefonoa(String telefonoa) {
		this.telefonoa = telefonoa;
	}


	/**
	 * @return the helbidea
	 */
	public String getHelbidea() {
		return helbidea;
	}


	/**
	 * @param helbidea the helbidea to set
	 */
	public void setHelbidea(String helbidea) {
		this.helbidea = helbidea;
	}


	/**
	 * @return the erabiltzaileIzena
	 */
	public String getErabiltzaileIzena() {
		return erabiltzaileIzena;
	}


	/**
	 * @param erabiltzaileIzena the erabiltzaileIzena to set
	 */
	public void setErabiltzaileIzena(String erabiltzaileIzena) {
		this.erabiltzaileIzena = erabiltzaileIzena;
	}


	/**
	 * @return the pasahitza
	 */
	public String getPasahitza() {
		return pasahitza;
	}


	/**
	 * @param pasahitza the pasahitza to set
	 */
	public void setPasahitza(String pasahitza) {
		this.pasahitza = pasahitza;
	}


	/**
	 * @return the helbideElektronikoa
	 */
	public String getHelbideElektronikoa() {
		return helbideElektronikoa;
	}


	/**
	 * @param helbideElektronikoa the helbideElektronikoa to set
	 */
	public void setHelbideElektronikoa(String helbideElektronikoa) {
		this.helbideElektronikoa = helbideElektronikoa;
	}

	
	
	
	
	
}
